Run server:
    ***In terminal enter: cd backend
    ***Run server: npm run start

Request package:
    ***npm i
key user aws


BF6ehOt9aoEwEvyqqPvfaBi6tsjen4AM1LksShX7


lylj srjy onqc solh

npv
3KU3UmlJhuZ+wvn1YldNJNN+dRfpJPG+INwlTIjm