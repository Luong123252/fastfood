// import { Space } from "antd";
import "./App.css";
import Layout from "./Components/Layout/Layout";
// import { Route, Routes, Navigate } from "react-router-dom";
// import Login from "./Components/Login/Login";

function App() {
  return (
    <Layout/>
  );
}
export default App;
