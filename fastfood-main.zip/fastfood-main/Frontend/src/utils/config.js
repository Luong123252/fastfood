export const BASE_URL = 'http://localhost:4000/api/v1'
// export const BASE_IMAGE_URL = 'http://localhost:4000'