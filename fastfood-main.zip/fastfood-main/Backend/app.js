const error = new Error('There was an error');

console.log(error.message) 