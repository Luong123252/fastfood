
class CustomAPIErorr extends Error {
    constructor(message){
        super(message);
    }
}

export default CustomAPIErorr;